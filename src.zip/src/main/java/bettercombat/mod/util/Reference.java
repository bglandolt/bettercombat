package bettercombat.mod.util;

public class Reference
{
	public static final String MOD_ID = "bettercombat";
	public static final String MOD_NAME = "Better Combat";
	public static final String VERSION = "1.5.6";
	public static final String CLIENT_PROXY_CLASS = "bettercombat.mod.client.ClientProxy";
	public static final String SERVER_PROXY_CLASS = "bettercombat.mod.util.CommonProxy";
}